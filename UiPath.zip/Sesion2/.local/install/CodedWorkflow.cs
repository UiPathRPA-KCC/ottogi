using System;
using System.Collections.Generic;
using System.Data;
using UiPath.CodedWorkflows;
using UiPath.Core;
using UiPath.Core.Activities.Storage;
using UiPath.Orchestrator.Client.Models;
using UiPath.Testing;
using UiPath.Testing.Activities.TestData;
using UiPath.Testing.Activities.TestDataQueues.Enums;
using UiPath.Testing.Enums;
using UiPath.UIAutomationNext.API.Contracts;
using UiPath.UIAutomationNext.API.Models;
using UiPath.UIAutomationNext.Enums;
using UiPath.CodedWorkflows.DescriptorIntegration;

namespace Sesion2
{
    public partial class CodedWorkflow : CodedWorkflowBase
    {
        public CodedWorkflow()
        {
            _ = new System.Type[]{typeof(UiPath.Testing.API.ITestingService), typeof(UiPath.UIAutomationNext.API.Contracts.IUiAutomationAppService), typeof(UiPath.Core.Activities.API.ISystemService)};
        }

        protected UiPath.Core.Activities.API.ISystemService system { get => serviceContainer.Resolve<UiPath.Core.Activities.API.ISystemService>(); }

        protected UiPath.Testing.API.ITestingService testing { get => serviceContainer.Resolve<UiPath.Testing.API.ITestingService>(); }

        protected UiPath.UIAutomationNext.API.Contracts.IUiAutomationAppService uiAutomation { get => serviceContainer.Resolve<UiPath.UIAutomationNext.API.Contracts.IUiAutomationAppService>(); }
    }
}

namespace Sesion2.ObjectRepository
{
    public static class Descriptors
    {
        public static class Chrome__ACME_System_1___Log_In_app
        {
            public static _Implementation._Chrome__ACME_System_1___Log_In_app.__Chrome__ACME_System_1___Log_In Chrome__ACME_System_1___Log_In { get; private set; } = new _Implementation._Chrome__ACME_System_1___Log_In_app.__Chrome__ACME_System_1___Log_In();
        }
    }
}

namespace Sesion2._Implementation
{
    internal class ScreenDescriptorDefinition : IScreenDescriptorDefinition
    {
        public IScreenDescriptor Screen { get; set; }

        public string Reference { get; set; }

        public string DisplayName { get; set; }
    }

    internal class ElementDescriptorDefinition : IElementDescriptorDefinition
    {
        public IScreenDescriptor Screen { get; set; }

        public string Reference { get; set; }

        public string DisplayName { get; set; }

        public IElementDescriptor ParentElement { get; set; }

        public IElementDescriptor Element { get; set; }
    }

    namespace _Chrome__ACME_System_1___Log_In_app._Chrome__ACME_System_1___Log_In
    {
        public class __Email : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Email(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "71O7hYPluEa_rYYTyyM6aA/O22x-tlvbkm3LcQqJu9Z2w", DisplayName = "Email", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Chrome__ACME_System_1___Log_In_app._Chrome__ACME_System_1___Log_In
    {
        public class __Login : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Login(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "71O7hYPluEa_rYYTyyM6aA/XsZxpdz7fUmYYGK7GPAC3Q", DisplayName = "Login", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Chrome__ACME_System_1___Log_In_app._Chrome__ACME_System_1___Log_In
    {
        public class __Password : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Password(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "71O7hYPluEa_rYYTyyM6aA/kgi8D-_9p0-b9jb9NkPuOw", DisplayName = "Password", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Chrome__ACME_System_1___Log_In_app
    {
        public class __Chrome__ACME_System_1___Log_In : IScreenDescriptor
        {
            public IScreenDescriptorDefinition GetDefinition()
            {
                return _screenDescriptor;
            }

            private readonly ScreenDescriptorDefinition _screenDescriptor;
            public __Chrome__ACME_System_1___Log_In()
            {
                _screenDescriptor = new ScreenDescriptorDefinition{Reference = "71O7hYPluEa_rYYTyyM6aA/iPs-W2Kqe0S-qN8bsjN6Bg", DisplayName = "Chrome: ACME System 1 - Log In", Screen = this};
                Email = new _Implementation._Chrome__ACME_System_1___Log_In_app._Chrome__ACME_System_1___Log_In.__Email(this, null);
                Login = new _Implementation._Chrome__ACME_System_1___Log_In_app._Chrome__ACME_System_1___Log_In.__Login(this, null);
                Password = new _Implementation._Chrome__ACME_System_1___Log_In_app._Chrome__ACME_System_1___Log_In.__Password(this, null);
            }

            public _Implementation._Chrome__ACME_System_1___Log_In_app._Chrome__ACME_System_1___Log_In.__Email Email { get; private set; }

            public _Implementation._Chrome__ACME_System_1___Log_In_app._Chrome__ACME_System_1___Log_In.__Login Login { get; private set; }

            public _Implementation._Chrome__ACME_System_1___Log_In_app._Chrome__ACME_System_1___Log_In.__Password Password { get; private set; }
        }
    }
}